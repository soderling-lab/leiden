A compiled iPSD proteome formed from the spatial proteomes of:
* Heller2012
* Kang2014
* Loh2016
* Nakamura2016
* Uezu2016

Genes were mapped to mouse homologs and stored as Entrez ids in the geneLists
package (`data(ciPSD)`).  

PPIs were compiled from the `getPPIs` package. Interactions from human, mouse,
and rat species were kept.  

See getPPIs/tutorials/compiled-iPSD-getPPIs for the
script which generated this network.  
